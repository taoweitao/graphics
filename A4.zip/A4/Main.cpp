#include <iostream>
#include "scene_lua.hpp"
#include "Primitive.hpp"

int main(int argc, char** argv)
{
  std::string filename = "Assets/simple.lua";
  if (argc >= 2) {
    filename = argv[1];
  }

  if (!run_lua(filename)) {
    std::cerr << "Could not open " << filename << std::endl;
    return 1;
  }
/*	Ray ray;
	ray.origin = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
	ray.direction = glm::vec4(0.0f, 0.0f, -1.0f, 0.0f);

	glm::vec3 P0 = glm::vec3(0.0f, 0.0f, -100.0f);
	glm::vec3 P1 = glm::vec3(0.0f, 100.0f, -100.0f);
	glm::vec3 P2 = glm::vec3(100.0f, 0.0f, -100.0f);
	double t = triIntersect(ray, P0, P1, P2);*/
}
